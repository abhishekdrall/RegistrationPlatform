package com.example.demo.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import com.example.demo.dao.PatientRecordDao;
import com.example.demo.entity.PatientRecord;

@org.springframework.stereotype.Service
public class UserService implements Service {

	@Autowired
	public PatientRecordDao patientRecordDao;
	
	@Override
	public List<PatientRecord> getPatientRecord() {
		return patientRecordDao.findAll(); 
	}

	@Override
	public PatientRecord addPatiendRecord(PatientRecord patientRecord) {
		patientRecordDao.save(patientRecord);
		return patientRecord;
	}

	@Override
	public PatientRecord updatePatientRecord(PatientRecord patientRecord) {
		patientRecordDao.save(patientRecord);
		return patientRecord;
	}

	
	@Override
	public void deletePatientRecord(Integer parseInt) {
	@SuppressWarnings("deprecation")
	PatientRecord prEntity=patientRecordDao.getOne(parseInt);
	patientRecordDao.delete(prEntity);
		
	}	
}
