package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.PatientRecord;
import com.example.demo.service.Service;

@RestController
@RequestMapping("/api")
public class UserController {
	
	@Autowired
	public Service services;
	
		
		//Get list of all stored Patient
		@GetMapping(path="patientrecorddetails",consumes="application/json")
		public List<PatientRecord> getPatientRecord(){
			return this.services.getPatientRecord();
		}
		
		// New Entry for Patient
		@PostMapping(path="addpatientrecord")
		public ResponseEntity<PatientRecord> addPatientRecord(@Valid @RequestBody PatientRecord patientRecord){
			PatientRecord savedPatientRecord=services.addPatiendRecord(patientRecord);
			return new ResponseEntity<PatientRecord>(savedPatientRecord, HttpStatus.CREATED);
		}
	
		// Update entry for Patient
		@PutMapping(path="updatepatientrecord")
		public PatientRecord updatePatientRecord(@RequestBody PatientRecord patientRecord) {
			return this.services.updatePatientRecord(patientRecord);
		}
		
		// Delete entry for Patient
		@DeleteMapping(path="deletepatientrecord/{pId}")
		public ResponseEntity<HttpStatus> deletePatientRecord(@PathVariable String pId){
			try {
				this.services.deletePatientRecord(Integer.parseInt(pId));
				return new ResponseEntity<>(HttpStatus.OK);
			}catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		

}
