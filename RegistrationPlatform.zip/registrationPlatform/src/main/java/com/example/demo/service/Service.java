package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.PatientRecord;

public interface Service {

	public List<PatientRecord> getPatientRecord();
	
	public PatientRecord addPatiendRecord(PatientRecord patientRecord);
	
	public PatientRecord updatePatientRecord(PatientRecord patientRecord);
	
	public void deletePatientRecord(Integer parseInt);
}
