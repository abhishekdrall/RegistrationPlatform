package com.example.demo.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;

//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.ToString;




@Entity
public class PatientRecord {
	
	@Id
	@GeneratedValue
	private int pId;
	
	@Size(min=3,message="Atleast 3 charaters")
	private String patName;
	@Size(min=10,message="Atleast 10 charaters")
	private String patAddress;
	@Email
	private String patEmail;
	@Size(min=10,message="Atleast 10 charaters + country code")
	private String patPhoneNumber;
	@ValidPassword
	private String patPassword;
	@CreationTimestamp
	private Date patDate;
	public String getPatName() {
		return patName;
	}
	public void setPatName(String patName) {
		this.patName = patName;
	}
	public String getPatAddress() {
		return patAddress;
	}
	public int getpId() {
		return pId;
	}
	public String getPatPassword() {
		return patPassword;
	}
	public void setPatPassword(String patPassword) {
		this.patPassword = patPassword;
	}
	//	public void setpId(int pId) {
//		this.pId = pId;
//	}
	public Date getPatDate() {
		return patDate;
	}
//	public void setPatDate(Date patDate) {
//		this.patDate = patDate;
//	}

	public void setPatAddress(String patAddress) {
		this.patAddress = patAddress;
	}
	public String getPatEmail() {
		return patEmail;
	}
	public void setPatEmail(String patEmail) {
		this.patEmail = patEmail;
	}
	public String getPatPhoneNumber() {
		return patPhoneNumber;
	}
	public void setPatPhoneNumber(String patPhoneNumber) {
		this.patPhoneNumber = patPhoneNumber;
	}
	@Override
	public String toString() {
		return "PatientRecord [pId=" + pId + ", patName=" + patName + ", patAddress=" + patAddress + ", patEmail="
				+ patEmail + ", patPhoneNumber=" + patPhoneNumber + ", patPassword=" + patPassword + ", patDate="
				+ patDate + "]";
	}
	public PatientRecord() {
		super();
	}

}



